/**
 * (c) Facebook, Inc. and its affiliates. Confidential and proprietary.
 */

//==============================================================================
// Welcome to scripting in Spark AR Studio! Helpful links:
//
// Scripting Basics - https://fb.me/spark-scripting-basics
// Reactive Programming - https://fb.me/spark-reactive-programming
// Scripting Object Reference - https://fb.me/spark-scripting-reference
// Changelogs - https://fb.me/spark-changelog
//==============================================================================

// How to load in modules
const Diagnostics = require('Diagnostics');
const Scene = require('Scene');

const NUI = require("NativeUI");
const M = require('Materials');
const Time = require('Time');

// Slider
var lastSliderValue = 0.5;
const mat = M.get('material2');
const nativeUISlider = NUI.slider;

nativeUISlider.value.monitor({fireOnInitialValue: false}).subscribe(function(val) {
    lastSliderValue = val.newValue;
    
    let sliderData = { 'sliderVal': lastSliderValue };

    mat.opacity = lastSliderValue;
  });
  
  function configureSlider(){
      nativeUISlider.value = lastSliderValue;
  }
  
  function init()
  {
    configureSlider();
    nativeUISlider.visible = true;
  }
  
  init();